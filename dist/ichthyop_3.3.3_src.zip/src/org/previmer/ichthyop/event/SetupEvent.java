/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.previmer.ichthyop.event;

import java.util.EventObject;

/**
 *
 * @author pverley
 */
public class SetupEvent extends EventObject {

    public SetupEvent(Object source) {
        super(source);
    }
}
